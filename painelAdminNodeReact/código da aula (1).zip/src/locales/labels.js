export default {
  users: "Usuários",
  projects: "Projetos",
  tasks: "Tarefas",
};
